""" XVM (c) https://modxvm.com 2013-2020 """

from xfw import IS_DEVELOPMENT

if IS_DEVELOPMENT:
    import profiler
