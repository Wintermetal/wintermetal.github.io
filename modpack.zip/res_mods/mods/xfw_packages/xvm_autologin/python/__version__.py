# This file was created automatically from build script
__xvm_version__ = '8.7.1'
__wot_version__ = '1.11.0.0'
__revision__ = '0006'
__branch__ = 'master'
__node__ = 'bc8dac8ca43887f429fd7dda23e203c987479e4f'
__development__ = 'False'
